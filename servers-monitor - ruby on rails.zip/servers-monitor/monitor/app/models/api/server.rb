class Api::Server
  include Mongoid::Document
end
