import { List } from '../list/list';

export class Board {
  id: number;
  name: string;
  lists: List[];
}
