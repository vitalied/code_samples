export class Task {
  id: number;
  list_id: number;
  name: string;
  position: number;
}
