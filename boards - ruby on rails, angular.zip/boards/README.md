# README

Run:

```docker-compose up --build```

In another console run:

```docker-compose exec api bundle exec rails db:migrate```

Open this URL in browser:

[http://localhost:4200](http://localhost:4200)
