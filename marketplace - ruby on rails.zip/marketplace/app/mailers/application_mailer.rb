class ApplicationMailer < ActionMailer::Base
  default from: "marketplace@example.com"
  layout 'mailer'
end
