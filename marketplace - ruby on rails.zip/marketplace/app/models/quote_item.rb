class QuoteItem < ActiveRecord::Base

  belongs_to :quote

end
