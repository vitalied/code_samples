Config.setup do |config|
  config.const_name = "Settings"
end