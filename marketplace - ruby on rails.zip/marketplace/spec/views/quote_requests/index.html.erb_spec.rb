require 'rails_helper'

RSpec.describe "quote_requests/index", type: :view do
  before(:each) do
  end

  it "renders a list of quotes" do
    render
  end
end
