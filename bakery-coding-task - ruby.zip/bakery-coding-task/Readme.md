# Coding Challenge Solution
# Requirements
- Ruby = 2.5.1

# Setup
- Goto project's folder in your terminal
- run `bundle install`
- now run `ruby bin/bakery_runner.rb input.txt` (`input.txt` is file with input data)

# Specs
if you want to run the specs please run `rspec .` in project's home directory.
