require 'products'
require 'product'
require 'product_pack'
require 'cart'
require 'cart_item'
require 'order'
require 'order_item'

describe Order do
  let(:order) { described_class.new }

  describe '#setup_from_cart' do
    let(:cart) { Cart.new }
    let(:product) { Product.new('AA', 'Croissant') }
    let(:product2) { Product.new('BB', 'Muffin') }
    before do
      product.add_product_pack(3, 6.99)
      product.add_product_pack(5, 8.99)

      product2.add_product_pack(2, 9.95)
      product2.add_product_pack(5, 16.95)
      product2.add_product_pack(8, 24.95)

      Products.class_variable_set(:@@products, [product, product2])
    end

    context 'invalid quantity' do
      before { cart.add_cart_item('AA', 2) }

      it 'should fail to create order_items' do
        order.setup_from_cart(cart)

        expect(order.order_items).to be_empty
      end
    end

    context 'valid quantity AA 10' do
      before { cart.add_cart_item('AA', 10) }

      it 'should create order_items' do
        order.setup_from_cart(cart)

        expect(order.order_items.size).to eql(1)

        order_item = order.order_items.first
        expect(order_item.product_code).to eql('AA')
        expect(order_item.product_pack_quantity).to eql(5)
        expect(order_item.quantity).to eql(2)
        expect(order_item.price_per_pack).to eql(8.99)
      end
    end

    context 'valid quantity BB 14' do
      before { cart.add_cart_item('BB', 14) }

      it 'should create order_items' do
        order.setup_from_cart(cart)

        expect(order.order_items.size).to eql(2)

        order_item = order.order_items.first
        expect(order_item.product_code).to eql('BB')
        expect(order_item.product_pack_quantity).to eql(8)
        expect(order_item.quantity).to eql(1)
        expect(order_item.price_per_pack).to eql(24.95)

        order_item = order.order_items.last
        expect(order_item.product_code).to eql('BB')
        expect(order_item.product_pack_quantity).to eql(2)
        expect(order_item.quantity).to eql(3)
        expect(order_item.price_per_pack).to eql(9.95)
      end
    end
  end

  describe '#calc_order_items_for_product' do
    it { expect(order.send(:calc_order_items_for_product, nil, [])).to be_nil }

    it { expect(order.send(:calc_order_items_for_product, 1, [])).to be_nil }

    it { expect(order.send(:calc_order_items_for_product, -1, [])).to be_nil }

    it { expect(order.send(:calc_order_items_for_product, 1, [5, 3])).to be_nil }

    it { expect(order.send(:calc_order_items_for_product, 5, [5])).to eql([5]) }

    it { expect(order.send(:calc_order_items_for_product, 10, [5, 3])).to eql [5, 5] }

    it { expect(order.send(:calc_order_items_for_product, 14, [8, 5, 2])).to eql [8, 2, 2, 2] }

    it { expect(order.send(:calc_order_items_for_product, 13, [9, 5, 3])).to eql [5, 5, 3] }
  end
end
