require 'products'
require 'product'

describe Products do
  before { Products.class_variable_set(:@@products, []) }

  describe 'self.products' do
    it 'should return empty' do
      expect(Products.products).to eq([])
    end

    context 'existing products' do
      let(:product) { Products.add_product('AA', 'Croissant') }

      it 'should return non empty' do
        expect(Products.products).to eq([product])
      end
    end
  end

  describe 'self.add_product' do
    it 'should fail with invalid product code' do
      expect{ Products.add_product('', '') }.to raise_error(StandardError, "Products: Product code is blank")
    end

    it 'should fail with invalid product name' do
      expect{ Products.add_product('AA', '') }.to raise_error(StandardError, "Products: Product name is blank")
    end

    context 'existing products' do
      before { Products.add_product('AA', 'Croissant') }

      it 'should fail with duplicate product code' do
        expect{ Products.add_product('AA', 'Croissant') }.to raise_error(StandardError, "Products: Duplicate code = AA for product")
      end

      it 'should fail with duplicate product name' do
        expect{ Products.add_product('BB', 'Croissant') }.to raise_error(StandardError, "Products: Duplicate name = Croissant for product")
      end
    end

    it 'should add product' do
      expect { Products.add_product('AA', 'Croissant') }.not_to raise_error
      expect(Products.products.size).to eql(1)
      product = Products.products.first
      expect(product.code).to eq('AA')
      expect(product.name).to eq('Croissant')
    end
  end

  describe 'self.find_product' do
    before { Products.add_product('AA', 'Croissant') }

    it 'should find product by code' do
      product = Products.find_product('AA')

      expect(product.code).to eq('AA')
      expect(product.name).to eq('Croissant')
    end

    it 'should not find product by wrong code' do
      product = Products.find_product('BB')

      expect(product).to be_nil
    end

    it 'should find product by name' do
      product = Products.find_product_by_name('Croissant')

      expect(product.code).to eq('AA')
      expect(product.name).to eq('Croissant')
    end

    it 'should not find product by wrong code' do
      product = Products.find_product_by_name('Muffin')

      expect(product).to be_nil
    end
  end
end
