require 'products'
require 'product'
require 'product_pack'

describe Product do
  let(:product) { described_class.new('AA', 'Croissant') }

  describe '.code' do
    subject { product.code }

    it { is_expected.to eq('AA') }
  end

  describe '.name' do
    subject { product.name }

    it { is_expected.to eq('Croissant') }
  end

  describe '.product_packs' do
    subject { product.product_packs }

    it { is_expected.to eq([]) }
  end

  describe 'self.add_product_pack' do
    it 'should fail with invalid quantity' do
      expect{ product.add_product_pack(0, 0) }.to raise_error(Product::QuantityError, "Product: Invalid quantity = 0 for product pack: AA")
    end

    it 'should fail with invalid price per pack' do
      expect{ product.add_product_pack(2, 0) }.to raise_error(Product::PriceError, "Product: Invalid price per pack = 0 for product pack: AA")
    end

    context 'existing product packs' do
      before { product.add_product_pack(2, 9.99) }

      it 'should fail with duplicate product pack quantity' do
        expect{ product.add_product_pack(2, 19.99) }.to raise_error(Product::QuantityError, "Product: Duplicate quantity = 2 for product pack: AA")
      end
    end

    it 'should add product pack' do
      expect { product.add_product_pack(2, 9.99) }.not_to raise_error
      expect(product.product_packs.size).to eql(1)
      product_pack = product.product_packs.first
      expect(product_pack.product_code).to eq('AA')
      expect(product_pack.quantity).to eq(2)
      expect(product_pack.price_per_pack).to eq(9.99)
    end
  end
end
