require 'order_item'

describe OrderItem do
  let(:order_item) { described_class.new('AA', 5, 2, 9.99) }

  describe '.product_code' do
    subject { order_item.product_code }

    it { is_expected.to eq('AA') }
  end

  describe '.product_pack_quantity' do
    subject { order_item.product_pack_quantity }

    it { is_expected.to eq(5) }
  end

  describe '.quantity' do
    subject { order_item.quantity }

    it { is_expected.to eq(2) }
  end

  describe '.price_per_pack' do
    subject { order_item.price_per_pack }

    it { is_expected.to eq(9.99) }
  end

  describe '#product_quantity' do
    subject { order_item.product_quantity }

    it { is_expected.to eq(5 * 2) }
  end

  describe '#total_price' do
    subject { order_item.total_price }

    it { is_expected.to eq(2 * 9.99) }
  end
end
