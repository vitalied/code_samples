require 'cart_item'

describe CartItem do
  let(:cart_item) { described_class.new('AA', 1) }

  describe '.product_code' do
    subject { cart_item.product_code }

    it { is_expected.to eq('AA') }
  end

  describe '.quantity' do
    subject { cart_item.quantity }

    it { is_expected.to eq(1) }
  end
end
