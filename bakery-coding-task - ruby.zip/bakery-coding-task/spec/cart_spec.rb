require 'products'
require 'product'
require 'cart'
require 'cart_item'

describe Cart do
  let(:cart) { described_class.new }
  let(:product) { Product.new('AA', 'Croissant') }

  before { Products.class_variable_set(:@@products, [product]) }

  describe 'self.add_cart_item' do
    it 'should fail with invalid product code' do
      expect{ cart.add_cart_item('BB', 0) }.to raise_error(StandardError, "Cart: Invalid code = BB for product")
    end

    it 'should fail with invalid quantity' do
      expect{ cart.add_cart_item('AA', 0) }.to raise_error(Cart::QuantityError, "Cart: Invalid quantity = 0 for product: AA")
    end

    context 'existing cart items' do
      before { cart.add_cart_item('AA', 2) }

      it 'should add quantity to existin cart item' do
        expect { cart.add_cart_item('AA', 3) }.not_to raise_error
        expect(cart.cart_items.size).to eql(1)
        cart_item = cart.cart_items.first
        expect(cart_item.product_code).to eq('AA')
        expect(cart_item.quantity).to eq(5)
      end
    end

    it 'should add cart item' do
      expect { cart.add_cart_item('AA', 2) }.not_to raise_error
      expect(cart.cart_items.size).to eql(1)
      cart_item = cart.cart_items.first
      expect(cart_item.product_code).to eq('AA')
      expect(cart_item.quantity).to eq(2)
    end
  end
end
