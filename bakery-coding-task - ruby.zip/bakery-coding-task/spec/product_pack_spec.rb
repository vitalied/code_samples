require 'product_pack'

describe ProductPack do
  let(:product_pack) { described_class.new('AA', 5, 18.99) }

  describe '.product_code' do
    subject { product_pack.product_code }

    it { is_expected.to eq('AA') }
  end

  describe '.quantity' do
    subject { product_pack.quantity }

    it { is_expected.to eq(5) }
  end

  describe '.price_per_pack' do
    subject { product_pack.price_per_pack }

    it { is_expected.to eq(18.99) }
  end
end
