class Cart

  class QuantityError < StandardError; end

  attr_accessor :cart_items

  def initialize
    @cart_items = []
  end

  def add_cart_item(product_code, quantity)
    raise StandardError, "Cart: Invalid code = #{product_code} for product" unless Products.find_product(product_code)
    quantity = quantity.to_i
    raise QuantityError, "Cart: Invalid quantity = 0 for product: #{product_code}" if quantity == 0

    if (cart_item = find_cart_item(product_code))
      cart_item.quantity += quantity
    else
      self.cart_items << CartItem.new(product_code, quantity)
    end
  end

  private

    def find_cart_item(product_code)
      index = self.cart_items.index { |cart_item| cart_item.product_code == product_code }
      self.cart_items[index] if index
    end

end
