class CartItem

  attr_accessor :product_code, :quantity

  def initialize(product_code, quantity)
    @product_code = product_code
    @quantity     = quantity
  end

end
