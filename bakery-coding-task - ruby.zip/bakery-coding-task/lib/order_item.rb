class OrderItem

  attr_accessor :product_code, :product_pack_quantity, :quantity, :price_per_pack

  def initialize(product_code, product_pack_quantity, quantity, price_per_pack)
    @product_code          = product_code
    @product_pack_quantity = product_pack_quantity
    @quantity              = quantity
    @price_per_pack        = price_per_pack
  end

  def product_quantity
    product_pack_quantity * quantity
  end

  def total_price
    quantity * price_per_pack
  end

end
