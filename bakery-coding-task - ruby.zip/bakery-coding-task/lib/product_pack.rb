class ProductPack

  attr_accessor :product_code, :quantity, :price_per_pack

  def initialize(product_code, quantity, price_per_pack)
    @product_code   = product_code
    @quantity       = quantity
    @price_per_pack = price_per_pack
  end

end
