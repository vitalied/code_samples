class Products

  @@products = []

  def self.products
    @@products
  end

  def self.add_product(code, name)
    raise StandardError, "Products: Product code is blank" if code.empty?
    raise StandardError, "Products: Duplicate code = #{code} for product" if self.find_product(code)
    raise StandardError, "Products: Product name is blank" if name.empty?
    raise StandardError, "Products: Duplicate name = #{name} for product" if self.find_product_by_name(name)

    product = Product.new(code, name)
    @@products << product

    product
  end

  def self.find_product(code)
    index = @@products.index { |product| product.code == code }
    @@products[index] if index
  end

  def self.find_product_by_name(name)
    index = @@products.index { |product| product.name == name }
    @@products[index] if index
  end

end
