class Order

  attr_accessor :order_items

  def initialize
    @order_items = []
  end

  def setup_from_cart(cart)
    cart.cart_items.each do |cart_item|
      begin
        product                  = Products.find_product(cart_item.product_code)
        product_packs_quantities = product.product_packs_quantities
        order_items_quantities   = calc_order_items_for_product(cart_item.quantity, product_packs_quantities)

        raise StandardError, "Order: Invalid quantity = #{cart_item.quantity} for product code = #{cart_item.product_code}" unless order_items_quantities

        order_items_quantities = order_items_quantities.reduce(Hash.new(0)) { |sum, key| sum[key] += 1; sum }

        order_items_quantities.each do |product_pack_quantity, quantity|
          product_pack = product.find_product_pack_by_quantity(product_pack_quantity)
          order_item   = OrderItem.new(product.code, product_pack_quantity, quantity, product_pack.price_per_pack)
          self.order_items << order_item
        end
      rescue => e
        puts e
      end
    end
  end

  private

    def calc_order_items_for_product(quantity, product_packs_quantities = [])
      # return nil if input data is invalid
      return if quantity.nil? || quantity <= 0 || product_packs_quantities.empty? || quantity < product_packs_quantities.min

      return [quantity] if product_packs_quantities.include?(quantity)

      # reject unuseful quantities
      product_packs_quantities = product_packs_quantities.reject { |pp_q| pp_q > quantity }.sort.reverse

      packs = { 0 => [] }

      until packs.has_key?(quantity)
        calc_packs = {}
        packs.each do |q, pack|
          product_packs_quantities.each do |pp_q|
            calc_packs[q + pp_q] = [pp_q] + pack if q + pp_q <= quantity && !packs.has_key?(q + pp_q)
          end
        end

        # return if solution is not found
        return if calc_packs.empty?

        packs.merge!(calc_packs)
      end

      packs[quantity].sort.reverse
    end

end
