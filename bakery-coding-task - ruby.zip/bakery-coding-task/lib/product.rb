class Product

  class QuantityError < StandardError; end
  class PriceError < StandardError; end

  attr_accessor :code, :name, :product_packs

  def initialize(code, name)
    @code          = code
    @name          = name
    @product_packs = []
  end

  def add_product_pack(quantity, price_per_pack)
    quantity = quantity.to_i
    raise QuantityError, "Product: Invalid quantity = 0 for product pack: #{self.code}" if quantity == 0
    raise QuantityError, "Product: Duplicate quantity = #{quantity} for product pack: #{self.code}" if find_product_pack_by_quantity(quantity)
    price_per_pack = price_per_pack.to_f
    raise PriceError, "Product: Invalid price per pack = 0 for product pack: #{self.code}" if price_per_pack == 0.0

    product_pack = ProductPack.new(self.code, quantity, price_per_pack)
    self.product_packs << product_pack

    product_pack
  end

  def find_product_pack_by_quantity(quantity)
    index = self.product_packs.index { |product_pack| product_pack.quantity == quantity }
    self.product_packs[index] if index
  end

  def product_packs_quantities
    self.product_packs.map { |product_pack| product_pack.quantity }
  end

end
